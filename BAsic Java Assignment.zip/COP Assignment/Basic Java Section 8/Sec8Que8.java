//Write a Java program to find the duplicate values of an array of integer values

package com.tester;

import java.util.Scanner;

public class Sec8Que8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		 Scanner sc = new Scanner(System.in);
	    	int[] arr = new int[5];
	        
	    	System.out.println("Enter array of 5 elements ");
	    	
	    	for(int i = 0 ; i<arr.length; i++) {
	             arr[i] = sc.nextInt();
	    	}
	    	System.out.println("Duplicate elements in given array: ");  
		
		for(int i = 0; i < arr.length; i++) {  
	            for(int j = i + 1; j < arr.length; j++) {  
	                if(arr[i] == arr[j])  
	                    System.out.println(arr[j]);  
	               
         	}
		}
	}
}


