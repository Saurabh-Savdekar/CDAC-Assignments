//Write a java program to read age of a person, check if he/she is eligible to cast vote or not.

import java.util.Scanner;
public class Sec3Que6{

    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter Age:");
       int Age=sc.nextInt();
       if(Age>17)
	   System.out.println("eligible to cast vote");
	   else 
	   System.out.println("not eligible to cast the vote");

	   sc.close();
}
}
