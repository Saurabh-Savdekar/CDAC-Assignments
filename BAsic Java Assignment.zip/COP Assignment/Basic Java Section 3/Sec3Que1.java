//Write a java program to swap two numbers stored in local variables

public class Sec3Que1{

    public static void main(String[] args) {
       
     int a=10,b=20;
     System.out.println("before swap :"+" a:"+a+" b:"+b);
     int temp = a;
     a=b;
     b=temp;
     System.out.println("before swap :"+" a:"+a+" b:"+b);
      
}
}
