//Write a program to find the largest of two numbers.


import java.util.Scanner;
public class Sec3Que8{

    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter Num1:");
   int Num1=sc.nextInt();
   System.out.println("Enter Num2:");
   int Num2=sc.nextInt();
       
       if(Num1>Num2)
	   System.out.println(Num1+" is greater");
       else 
	   System.out.println(Num2+" is greater");
	   sc.close();
}
}
