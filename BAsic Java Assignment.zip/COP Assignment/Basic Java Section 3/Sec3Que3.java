//Write a java program to accept two integers and check whether they are equal or not.

import java.util.Scanner;
public class Sec3Que3{

    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       System.out.println("a:");
     int a = sc.nextInt();
     System.out.println("b:");
     int b = sc.nextInt();
     if(a==b)
     System.out.println("equals");
     else
     System.out.println("not equals");
   
}
}
