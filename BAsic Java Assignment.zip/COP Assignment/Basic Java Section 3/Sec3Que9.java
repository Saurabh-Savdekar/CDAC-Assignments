//Write a program to find the largest of three numbers

import java.util.Scanner;
public class Sec3Que9{

    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter Num1:");
   int Num1=sc.nextInt();
   System.out.println("Enter Num2:");
   int Num2=sc.nextInt();
   System.out.println("Enter Num3:");
   int Num3=sc.nextInt();
      int temp=Num1>Num2?Num1:Num2;
	   int c=Num3>temp?Num3:temp;
	   System.out.println(c+" is greater");
	   sc.close();
}
}
