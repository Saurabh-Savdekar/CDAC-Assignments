//Write a java program to swap two numbers stored in local variables without using additional variable

public class Sec3Que2{

    public static void main(String[] args) {
       
     int a=10,b=20;
     System.out.println("before swap :"+" a:"+a+" b:"+b);
     a=a+b-a;
     b=a+b-b;
     System.out.println("before swap :"+" a:"+a+" b:"+b);
   
}
}
