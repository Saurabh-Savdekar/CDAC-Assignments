//Write a program to read 5 numbers from user, print the second highest number.

import java.util.*;

public class Sec3Que20{
    public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    int max=0;
    int arr[]=new int [5];
    System.out.println("Enter 5 numbers:");
    for(int i=0;i<5;i++)
    {
    arr[i]=sc.nextInt();
    }
   Arrays.sort(arr);
System.out.println("2nd highest no: "+arr[5-2]);
sc.close();
}
}

