//Write a java program to check whether a given number is even or odd.

import java.util.Scanner;
public class Sec3Que5{

    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter num:");
       int num=sc.nextInt();
       if(num%2==0)
	   System.out.println("Even");
	   else 
	   System.out.println("Odd");

	   sc.close();
}
}
