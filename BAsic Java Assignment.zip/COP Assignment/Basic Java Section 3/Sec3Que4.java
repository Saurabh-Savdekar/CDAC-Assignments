//Write a java program to check whether a given number is positive or negative.

import java.util.Scanner;
public class Sec3Que4{

    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter num:");
       int num=sc.nextInt();
       if(num>0)
	   System.out.println("positive");
	   else 
	   System.out.println("negative");

	   sc.close();
}
}
	