// Write a Java program to print 'Hello' on screen and then print your name on a separate line. 

public class Sec1Que3 {

 public static void main(String args[]){
         
        
 		  System.out.println("Hello");
          System.out.println("Saurabh");



   }
}
