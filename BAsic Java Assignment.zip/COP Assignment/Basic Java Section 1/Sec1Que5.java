//Write a program to take "name" as command line argument and print "Hello "+<name> on the console

public class Sec1Que5 {

 public static void main(String args[]){
         
        
 		  System.out.println("Hello"+" "+args[0]);
          



   }
}