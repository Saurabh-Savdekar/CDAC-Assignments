// Write a program to get the largest element of an array using recursion

package com.tester;
import java.util.*;

public class Sec9Que8 {

	public static int findMaxRec(int array[], int n)
    {
      
      if(n == 1)
        return array[0];
         
        return Math.max(array[n-1], findMaxRec(array, n-1));
    }
	     
	  
	    public static void main(String args[])
	    {
	    	Scanner sc = new Scanner(System.in);
	    	System.out.println("Enter array of 6 elements ");
	    	
	    	int[] array = new int[6];  
	    	int n = array.length;
	    	
	    	for(int i=0; i<n; i++)  
	    	{  
	    	  
	    	array[i]=sc.nextInt();  
	    	} 
	        
	         
	    	System.out.println("Maximum number in array is ");
	    	 System.out.println(findMaxRec(array, n));
	    }
	}