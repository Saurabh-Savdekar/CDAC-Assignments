/*
Write a program to make such a pattern like right angle triangle with a number which will repeat a number in a row, as shown below : 
1
22
333
4444
*/

import java.util.Scanner;

public class Sec4Que7{
    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("no. of rows:");
   int row=sc.nextInt();
   for(int i=1;i<=row;i++){
       for(int j=1;j<=i;j++){
        System.out.print(i);
       }
       System.out.println();
       }
}
}
