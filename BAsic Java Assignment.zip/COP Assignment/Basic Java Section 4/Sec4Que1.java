//Write a java program to print first 10 natural numbers and their sum.

public class Sec4Que1{
    public static void main(String[] args) {
   int num=10,i,sum=0;
   for(i=1;i<=num;i++)
   {
       sum=sum+i;
   }

System.out.println("Sum of 1st 10 natural no.: "+sum);

    }
}
