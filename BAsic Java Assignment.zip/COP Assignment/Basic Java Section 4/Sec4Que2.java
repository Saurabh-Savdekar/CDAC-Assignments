//Write a java program to read 10 numbers from keyboard and find their  sum and average.

import java.util.Scanner;

public class Sec4Que2{
    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   int sum=0;
   System.out.println("enter 10 numbers:");
   for(int i=0;i<10;i++){
   int num=sc.nextInt();
   sum=sum+num;   
}

System.out.println("Sum of 10  no.: "+sum);

    }
}
