/*
Write a program to make such a pattern like right angle triangle with number increased by 1 as shown below : 
1
2 3
4 5 6
7 8 9 10
*/

import java.util.Scanner;

public class Sec4Que8{
    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   int n=1;
   System.out.println("no. of rows:");
   int row=sc.nextInt();
   for(int i=1;i<=row;i++){
       for(int j=1;j<=i;j++){
        System.out.print(n+" ");
        n++;
       }
       System.out.println();
       }
}
}
