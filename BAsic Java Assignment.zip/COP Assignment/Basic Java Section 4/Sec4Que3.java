//Write a program in java to display the multiplication table of a given integer.

import java.util.Scanner;

public class Sec4Que3{
    public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter number:");
   int num=sc.nextInt();
   for(int i=1;i<=10;i++){
System.out.println(num+"*"+i+"="+(num*i));
}


    }
}
